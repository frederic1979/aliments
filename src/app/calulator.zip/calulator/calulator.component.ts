import { Component, OnInit } from '@angular/core';
import{AlimentsService} from '../aliments.service';
import { FormBuilder} from "@angular/forms";
import { Aliment } from '../aliment';

@Component({
  selector: 'app-calulator',
  templateUrl: './calulator.component.html',
  styleUrls: ['./calulator.component.css']
})
export class CalulatorComponent implements OnInit {
  

  calculatorAlimentList = this.alimentService.aliments;
  
formula = this.formbuilder.group({
    
  aliment : "",
  portion : ""

});


tableau=[];
  constructor( private alimentService:AlimentsService,
    private formbuilder : FormBuilder ) { }



    fonctionInject(alimentPortion)
    {
     console.log (alimentPortion);
    // (indice*portion)/100
    
     
      
    }

  ngOnInit() {
  }

}
